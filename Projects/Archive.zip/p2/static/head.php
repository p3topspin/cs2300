<meta charset="utf-8">
<title>Written</title>
<link rel="shortcut icon" href="http://faviconist.com/icons/51dc756da7e23def35bb5ca3cd2afa7b/favicon.ico" />

<!--CSS, fonts, resources-->

<!--Eric Meyer's reset.css - resets padding, margin and other defaults http://meyerweb.com/eric/tools/css/reset/-->
<link href="css/reset.css" rel="stylesheet">
<!--Google Fonts Lato-->
<link href='http://fonts.googleapis.com/css?family=Lato:300,400,300italic,400italic' rel='stylesheet' type='text/css'>
<!--Font Awesome Icon Font-->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<!--Custom CSS for all pages-->
<link rel="stylesheet" href="css/stylesheet.css">
<!--Adobe Typekit for fonts-->
<script src="//use.typekit.net/nae4gtv.js"></script>
<script>try{Typekit.load();}catch(e){}</script>

<!--Scripts-->

<!--jQuery CDN-->
<script src="http://code.jquery.com/jquery-1.11.2.min.js"></script>

<!--Custom Javascript-->
<script src="js/main.js"></script>