#CS2300 - Project 1
A 5-page personal website implemented using only HTML, PHP, JavaScript, and jQuery.
