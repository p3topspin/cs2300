<!DOCTYPE html>
<html>
    <head>
	<title>info230</title>
    </head>
    <body>
	<h1>PHP SuperBowl</h1>
	<h3>Patriots fans are subject to grade deflation worth 2/13ths of the points due to "atmospheric conditions" and "equilibrium".</h3>
	<p>Welcome to the greatest PHP review there ever was. In honor of this weekend's game, put the team on yo back and fill out the missing (or incomplete) PHP code to fix the form and display lists of the players on each team. </p>
	
	
	<form action="lab2activity.php" method="POST">	
		
		If you wish to add a player to the Seahawks roster, select "Seattle Seahawks" from the below menu.<br/>  If you wish to add a player to a team that cheats
		its way into the superbowl, select "New England Patriots".<br/>
		<input type="text" name="newPlayer" /><br/>
		<select name="newTeam">
			<option value="Seattle Seahawks">Seattle Seahawks</option>
			<option value="New England Patriots">New England Patriots</option>
		</select>
		<input type="submit" name="submit" value="Add Player" />
	</form>
	
	<?php
	    //the current associative array of players; don't edit
	    $players = array(	'Russell Wilson' => 'Seattle Seahawks',
				    'Tom Brady' => 'New England Patriots',
				    'Richard Sherman' => 'Seattle Seahawks',
				    'Marshawn Lynch' => 'Seattle Seahawks',
				    'Rob Gronkowski' => 'New England Patriots'
	    );
			    
	    //First down: Fix the if statement so that it tests whether the page is loading because the submit button was clicked. What PHP function do you know that does this?
	    if(true){
	
		/*uncomment when you have fixed if-statement above
		$newPlayer=$_POST['newPlayer'];		
		$newTeam=$_POST['newTeam'];	
		*/
			
		//Second down: if newPlayer and newTeam are set and newPlayer matches the regular expression, then add it to the array to be printed	
		if(
			isset($newPlayer) && 
			isset($newTeam) && 
			preg_match(/*allow only letters (either case) or spaces, remember that there are two arguments for preg_match: the pattern and the string to test*/)
			){
				//Now add the new player to the $players array
				//$players[] = ;
		}
		else{
			echo '<h3>Please enter a valid player name for it to be added!</h3>';
		}
	    }
	?>
	
	<p>Print the list of players using a foreach loop</p>
	
	<?php
	    echo '<ul>';
	    /* Third and goal: Fill in the foreach parameters and the if statement, then uncomment this block
	    foreach( ){  
		    echo '<li>';  //Print out the key and value, as in "Tom Brady plays for the New England Patriots". We've gotten you started by adding <li>.
		    
		    if(){ //Fix the if statement so that the appropriate logo prints. (Looking at the next line you'll realize that the if should check if the team is Seattle.)
			    $url = 'sea.png';
			    }
		    else{
			    $url = 'nep.gif';
			    }
		    echo "<img src='$url' width='25' alt='team logo' />";
		    echo '</li>';
	    }*/
	    echo '</ul>';
	    
	    //Touchdown! If there's time left, go for the two-point conversion.
	?>
	
	
	<p>Recreate the above using a function</p>
	
	<?php
	    //Two point conversion: define function here -- there should be two arguments.
	    function printName(){  
		    //Take function content from foreach above, but NOT the actual loop. That will be called below.
	    }
	    
	    echo '<ul>';
	    
	    /*Call the function using a foreach (similar setup to before) loop
	    foreach( ){
		    
	    }
	    */
	    
	    echo '</ul>';
	    
	    //Great job! You scored a TD and punched the two-point conversion in. Enjoy the Super Bowl this weekend!
	?>
    
    </body>
</html>
